#include <stdio.h>
#include <sys/types.h>
#include <wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <sched.h>


int main()
{
    int i, pid[3], ppid, status, result;
    pid[0]=getpid();
    ppid=getppid();
    printf("\nFather parameters was: pid=%i ppid=%i\n", pid[0],ppid);

    if((pid[2] = fork()) == 0)
    {
        execl("son_2", "son_2", NULL);
    }
    if((pid[1] = fork()) == 0)
    {
        execl("son_1", "son_1", NULL);
    }

    system("ps xf > log.txt");
    for (i = 1; i < 3; i++)
    {
        // WUNTRACED - сообщает статус остановленного процесса-потомка
        result = waitpid(pid[i], &status, WUNTRACED);
        printf("Child proccess with pid = %d is finished with status %d\n", result, status);
    }
}
