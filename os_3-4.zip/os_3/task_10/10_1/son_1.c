#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <wait.h>


int main()
{
    int pid, ppid, status, result;
    pid = getpid();
    ppid = getppid();

    printf("PROCESS son1 PARAM: pid=%i ppid=%i\n", pid, ppid);

    if (fork() == 0){
        status = execl("son1_1", "son1_1", NULL);
    }

    system("ps xf > log.txt");
    result = waitpid(pid, &status, WUNTRACED);
    printf("Child proccess with pid = %d is finished with status %d\n", result, status);
    return 0;
}
