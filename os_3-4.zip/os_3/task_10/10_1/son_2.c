#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

int main()
{
    int pid, ppid;
    pid = getpid();
    ppid = getppid();

    printf("PROCESS son2 PARAM: pid=%i ppid=%i\n", pid, ppid);
    sleep(5);

    return 0;
}
