#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    int pid, ppid, status;
    pid = getpid();
    ppid = getppid();
    printf("FATHER PARAM: pid=%i ppid=%i\n", pid, ppid);

    pid_t child_pid = fork();

    if (child_pid == -1) {
        perror("fork");
        exit(EXIT_FAILURE);
    }
    else if (child_pid == 0) {
        if (execl("./son", "son", NULL) == -1) {
            perror("execl");
            exit(EXIT_FAILURE);
        }
    }
    else {
        wait(&status);
        printf("Child process is finished with status %d\n", status);
        system("ps xf > file.txt");
    }

    return 0;
}
