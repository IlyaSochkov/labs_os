#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_NUM 10000

int main() {
    int sum = 0;
    pid_t pid;
    int status;

    pid = fork();

    if (pid < 0) {
        fprintf(stderr, "Failed to fork\n");
        exit(1);
    } else if (pid == 0) { // child process
        for (int i = 1; i <= MAX_NUM / 2; i++) {
            sum += i;
        }
        exit(sum);
    } else { // parent process
        for (int i = MAX_NUM / 2 + 1; i <= MAX_NUM; i++) {
            sum += i;
        }
        wait(&status);
        sum += WEXITSTATUS(status);
        printf("Sum is %d\n", sum);
    }

    return 0;
}
