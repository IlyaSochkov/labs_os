#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <sys/wait.h>

int main() {
    fflush(stdout);
    pid_t pid;
    int policy = SCHED_RR;
    struct sched_param params;

    params.sched_priority = 1;

    pid = fork();

    if (pid < 0) {
        fprintf(stderr, "Failed to fork\n");
        exit(1);
    } else if (pid == 0) { // child process
        printf("Child process with pid %d is calculating\n", getpid());

        if (sched_setscheduler(0, policy, &params) == -1) {
            perror("Failed to set scheduling policy for child process");
            exit(1);
        }

        for (int i = 0; i < 100000000; i++) {
            int a = 10;
            int b = 20;
            int c = a + b;
        }

        printf("Child process with pid %d has finished calculating\n", getpid());
        exit(0);
    } else { // parent process
        printf("Parent process with pid %d is calculating\n", getpid());

        if (sched_setscheduler(0, policy, &params) == -1) {
            perror("Failed to set scheduling policy for parent process");
            exit(1);
        }

        for (int i = 0; i < 100000000; i++) {
            int a = 10;
            int b = 20;
            int c = a + b;
        }
        wait(NULL);
        printf("Parent process with pid %d has finished calculating\n", getpid());
    }

    printf("Exiting process with pid %d\n", getpid());
    return 0;
}
