#include <stdio.h>


void main()
{
	int i;
	for(i = 0; i < 100000000; i++);
}
