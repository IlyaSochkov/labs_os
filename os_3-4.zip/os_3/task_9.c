#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    pid_t pid1, pid2, pid3;
    int status;

    // создаем первый процесс с помощью функции execl()
    pid1 = fork();
    if (pid1 == 0) {
        execl("/bin/ls", "ls", "-l", NULL);
    }

    // создаем второй процесс с помощью функции execlp()
    pid2 = fork();
    if (pid2 == 0) {
        execlp("ps", "ps", "-ef", NULL);
    }

    // создаем третий процесс с помощью функции execv()
    char *args[] = {"whoami", NULL};
    pid3 = fork();
    if (pid3 == 0) {
        execv("/usr/bin/whoami", args);
    }

    // ждем, пока первый и второй процессы завершат свою работу
    waitpid(pid1, &status, 0);
    waitpid(pid2, &status, 0);

    return 0;
}
